#### Spanish
- Escribir una clase llamada SuperMarket que implemente el funcionamiento de n cajas de supermercado.
- Los m clientes del supermercado estarán un tiempo aleatorio comprando y con posterioridad se situarán en una única cola.
- Cuando cualquier caja esté disponible, el primero de la cola será atendido en la caja correspondiente.
